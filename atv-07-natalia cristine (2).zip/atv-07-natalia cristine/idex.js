const ano_atual ="2023"

//recolher o nome e ano de nascimento do usuario

let nome = prompt ("digite seu nome:")
let ano_nascimento = parseInt(prompt("Digite seu ano de nascimento:"))

console.log(nome)
console.log(ano_nascimento)

let idade = ano_atual - ano_nascimento

console.log("Olá " + nome + ", você tem " + idade + " anos.")





    
